# Контракты API и событий — {{DOMAIN}}

Срез API: `schema/openapi.yaml`.

События: `events/specs/*` (JSON Schema), публикация через общий outbox.

